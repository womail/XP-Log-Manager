This zip contains:
- SkunkcraftsUpdater.app for MacOS (both Intel and Apple Silicon)
- SkunkcraftsUpdater.exe for Windows 10/11
- SkunkcraftsUpdater_lin for GNU/Linux (tested on Ubuntu 22.04)
- README.txt this file.

Just extract from the zip file the binary you need for your operating system
into your main X-Plane folder. If you have multiple installations of X-Plane,
then copy it to each instance. You MUST run the application from the X-Plane
folder.

On MacOS you must authorize the app to run through Settings/Security.

